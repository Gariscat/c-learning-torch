from networks import CLearningCritic, Actor
from utils import split_into_obs_and_act
import torch
from torch import nn
from torch.optim import Adam
import numpy as np
import random
import os


OBS_DIM = 39
ACT_DIM = 4


"""
class Trajectory():
    def __init__(self, max_len=500) -> None:
        self.obs_sequence = []
        self.act_sequence = []
        
    def push(self, obs, act=None):
        self.obs_sequence.append(obs)
        self.act_sequence.append(act)
        
    def sample_transition(self):
        num_s = len(self.obs_sequence)
        idx = np.random.choice(num_s-1)
        return (self.obs_sequence[idx], self.act_sequence[idx], self.obs_sequence[idx+1])
        
        
class ReplayBuffer():
    def __init__(self, buffer_size=1024) -> None:
        self.data = []
        self.buffer_size = buffer_size
        
    def push(self, trajectory):
        if len(self.data) >= self.buffer_size:
            self.data.pop(0)
        self.data.append(trajectory)
        
    def sample(self, batch_size=8):
        return random.sample(self.data, batch_size)
    
"""

class ReplayBuffer():
    def __init__(self, buffer_size=int(1e5)) -> None:
        self.transitions = []
        self.buffer_size = buffer_size
        
    def push(self, s_t, a_t, s_t_1):
        if len(self.transitions) >= self.buffer_size:
            self.transitions.pop(0)
        s_t = torch.from_numpy(s_t).float()
        a_t = torch.from_numpy(a_t).float()
        s_t_1 = torch.from_numpy(s_t_1).float()
        self.transitions.append([s_t, a_t, s_t_1])
        
    def sample_transitions(self, batch_size):
        return random.sample(self.transitions, batch_size)


class CLearning():
    def __init__(self, env, args) -> None:
        self.env = env
        self.env.seed(args.seed)
        self.max_steps = args.max_steps
        
        self.lr = args.lr
        self.batch_size = args.batch_size
        self.gamma = args.gamma
        self.seed = args.seed
        
        self.obs_dim = env.observation_space.shape[0]
        self.act_dim = env.action_space.shape[0]
        
        self.critic = CLearningCritic(self.obs_dim, self.act_dim, args.hidden_dim)
        self.critic_optim = Adam(self.critic.parameters(), lr=args.lr)
        
        self.actor = Actor(self.obs_dim, self.act_dim, args.hidden_dim)
        self.actor_optim = Adam(self.actor.parameters(), lr=args.lr)
        
        self.memory = ReplayBuffer(args.replay_size)
        
        """collect a list of possible goals"""
        self.goals = []
        for _ in range(args.num_goal_obs):
            o = self.sample_obs(is_goal=True)
            self.goals.append(o)
            # print(o)
            
    def to(self, device):
        self.actor.to(device)
        self.critic.to(device)
        
    def act(self, s_t, s_g, device, deterministic=False):
        s_t = torch.tensor(s_t, dtype=torch.float32).to(device)
        s_g = torch.tensor(s_g, dtype=torch.float32).to(device)
        a, _ = self.actor(s_t, s_g, deterministic)
        return a
    
    def sample_obs(self, is_goal=False):
        o = self.env.observation_space.sample()
        l = self.env.observation_space.shape[0]
        if is_goal:
            goal = self.env.goal_space.sample()
            g = np.pad(goal, (l-self.env.goal_space.shape[0], 0), 'constant', constant_values=0)
        else:
            g = 0
        o = torch.from_numpy(o+g).float()
        return o
    
    def update_parameters(self, device):
        transitions = self.memory.sample_transitions(self.batch_size)
        
        s_t = torch.stack([x for x, _, __ in transitions]).to(device)
        a_t = torch.stack([x for _, x, __ in transitions]).to(device)
        s_t_1 = torch.stack([x for _, __, x in transitions]).to(device)
        s_g = torch.stack([self.sample_obs()]*self.batch_size).to(device)
        
        # print(s_t.shape, a_t.shape, s_t_1.shape, s_g.shape)
        
        log_prob_s_t_a_t_s_t_1 = self.critic(s_t, a_t, s_t_1)
        log_prob_s_t_a_t_s_g = self.critic(s_t, a_t, s_g)
        
        # print(log_prob_s_t_a_t_s_t_1.shape, log_prob_s_t_a_t_s_g.shape)
        
        a_t_1 = self.act(s_t_1, s_g, device)
        importance_temp = self.critic(s_t_1, a_t_1, s_g).detach().exp()
        
        with torch.no_grad():
            w = importance_temp[:, 1] / importance_temp[:, 0]
        
        critic_loss = (
            (1 - self.gamma) * log_prob_s_t_a_t_s_t_1[:, 1] \
            + log_prob_s_t_a_t_s_g[:, 0] \
            + self.gamma * w * log_prob_s_t_a_t_s_g[:, 1]
        ).mean()
        self.critic_optim.zero_grad()
        critic_loss.backward()
        self.critic_optim.step()
        
        a_t = self.act(s_t, s_g, device)
        actor_loss = -self.critic(s_t, a_t, s_g).mean()
        actor_loss.backward()
        self.actor_optim.step()
        
        return critic_loss.item(), actor_loss.item()
        
    # Save model parameters
    def save_checkpoint(self, env_name, suffix="", ckpt_path=None):
        if not os.path.exists('checkpoints/'):
            os.makedirs('checkpoints/')
        if ckpt_path is None:
            ckpt_path = "checkpoints/c_learning_checkpoint_{}_{}".format(env_name, suffix)
        # print('Saving models to {}'.format(ckpt_path))
        torch.save({'actor_state_dict': self.actor.state_dict(),
                    'critic_state_dict': self.critic.state_dict(),
                    'critic_optimizer_state_dict': self.critic_optim.state_dict(),
                    'actor_optimizer_state_dict': self.actor_optim.state_dict()}, ckpt_path)

    # Load model parameters
    def load_checkpoint(self, ckpt_path, evaluate=False):
        print('Loading models from {}'.format(ckpt_path))
        if ckpt_path is not None:
            checkpoint = torch.load(ckpt_path)
            self.actor.load_state_dict(checkpoint['actor_state_dict'])
            self.critic.load_state_dict(checkpoint['critic_state_dict'])
            self.critic_optim.load_state_dict(checkpoint['critic_optimizer_state_dict'])
            self.actor_optim.load_state_dict(checkpoint['actor_optimizer_state_dict'])

            if evaluate:
                self.actor.eval()
                self.critic.eval()
            else:
                self.actor.train()
                self.critic.train()
                