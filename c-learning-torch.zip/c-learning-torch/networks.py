from turtle import forward
import torch
from torch import nn
from copy import deepcopy
from torch.nn import functional as F
from torch.distributions import Distribution, Normal
LOG_SIG_MIN = -10
LOG_SIG_MAX = 2
ACTION_BOUND_EPSILON = 1E-6


def weights_init_(m):
    # weight init helper function
    if isinstance(m, nn.Linear):
        torch.nn.init.xavier_uniform_(m.weight, gain=1)
        torch.nn.init.constant_(m.bias, 0)


class CLearningCritic(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim=128) -> None:
        super().__init__()
        self.input_dim = obs_dim * 2 + act_dim
        self.net = nn.Sequential(
            nn.Linear(self.input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 2),
            nn.LogSoftmax(dim=1)
            # nn.Sigmoid()
        )
        # self.encoder_g = deepcopy(self.encoder_c)
        self.apply(weights_init_)
        
    def forward(self, s_t, a_t, s_g):
        input_t = torch.cat((s_t, a_t, s_g), dim=-1)
        output = self.net(input_t)
        return output
        
        
class Actor(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim=128, action_scale=1, action_bias=0) -> None:
        super().__init__()
        self.input_dim = obs_dim * 2
        self.encoder = nn.Sequential(
            nn.Linear(self.input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
        )
        self.fc_mean = nn.Linear(hidden_dim, act_dim)
        self.fc_log_std = nn.Linear(hidden_dim, act_dim)
        """self.last_layer_mean = nn.Sequential(
            nn.Linear(hidden_dim, act_dim),
            nn.Tanh()
        )
        # self.last_layer_log_std = nn.Linear(hidden_dim, act_dim)
        self.last_layer_std = nn.Sequential(
            nn.Linear(hidden_dim, act_dim),
            nn.Sigmoid()
        )
        # since x is in [-1, 1], then μ is in [-1, 1] and σ is in [0, 1]"""
        self.action_scale = action_scale
        self.action_bias = action_bias
        self.apply(weights_init_)

        
    def forward(self, s_t, s_g, deterministic=False, ret_log_prob=False):
        # print(s_t.shape, s_g.shape)
        input_t = torch.cat((s_t, s_g), dim=-1)
        t = self.encoder(input_t)
        mean = self.fc_mean(t)
        log_std = self.fc_log_std(t)
        log_std = torch.clamp(log_std, LOG_SIG_MIN, LOG_SIG_MAX)
        std = torch.exp(log_std)
        
        normal = Normal(mean, std)
        x_t = normal.rsample() if deterministic == False else mean
        y_t = torch.tanh(x_t)
        action = y_t * self.action_scale + self.action_bias
        mean = torch.tanh(mean) * self.action_scale + self.action_bias
        if not ret_log_prob:
            return action, mean
        else:
            log_prob = normal.log_prob(x_t)
            # Enforcing Action Bound
            log_prob -= torch.log(self.action_scale * (1 - y_t.pow(2)) + ACTION_BOUND_EPSILON)
            log_prob = log_prob.sum(1, keepdim=True)
            return action, log_prob, mean