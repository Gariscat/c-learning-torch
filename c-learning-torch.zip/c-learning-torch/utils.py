import torch

def split_into_obs_and_act(state, obs_dim, act_dim):
    if state.shape[-1] == obs_dim * 2 + act_dim:  # s, a, s'
        return (
            state[:, :obs_dim],
            state[:, obs_dim:obs_dim+act_dim],
            state[:, obs_dim+act_dim:]
        )
    elif state.shape[-1] == obs_dim * 2:  # s, s'
        return (
            state[:, :obs_dim],
            state[:, obs_dim:]
        )