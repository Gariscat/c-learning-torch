import argparse
import metaworld
import random
from agents import *
import itertools
import numpy as np
import random
import torch
import datetime
from torch.utils.tensorboard import SummaryWriter


parser = argparse.ArgumentParser(description='PyTorch C-Learning Args')
parser.add_argument('--env_name', default="pick-place-v2",
                    help='Mujoco Gym environment (default: pick-place-v2)')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor for reward (default: 0.99)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='G',
                    help='learning rate (default: 0.001)')
parser.add_argument('--device', type=str, default="cuda" if torch.cuda.is_available() else "cpu",
                    help='run on CUDA (default: False)')
parser.add_argument('--seed', type=int, default=123456, metavar='N',
                    help='random seed (default: 123456)')
parser.add_argument('--max_steps', type=int, default=500, metavar='N',
                    help='maximum number of steps (default: 500)')
parser.add_argument('--batch_size', type=int, default=128, metavar='N',
                    help='batch size (default: 128)')
parser.add_argument('--num_steps', type=int, default=100000, metavar='N',
                    help='maximum number of steps (default: 100000)')
parser.add_argument('--hidden_dim', type=int, default=128, metavar='N',
                    help='hidden size (default: 128)')
parser.add_argument('--replay_size', type=int, default=10000, metavar='N',
                    help='size of replay buffer (default: 100000)')
parser.add_argument('--num_goal_obs', type=int, default=128, metavar='N',
                    help='number of possible goals (default: 16)')
parser.add_argument('--eval_interval', type=int, default=100, metavar='N',
                    help='number of steps to evaluate (default: 1000)')
parser.add_argument('--steps_per_update', type=int, default=1, metavar='N',
                    help='number of steps per update (default: 1)')


def train(train_env, eval_env, agent, args):
    os.makedirs('runs/', exist_ok=True)
    file_name = 'runs/{}_clearning_{}'.format(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"), args.env_name)
    writer = SummaryWriter(file_name)
    
    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    train_env.seed(args.seed)
    eval_env.seed(args.seed)   

    global_step = 0
    update_step = 0
    
    agent.to(args.device)
    
    for i_episode in itertools.count(1):
        in_episode_step = 0
        cur_o = train_env.reset()
        goal_o = random.choice(agent.goals)
        done = False
        
        total_r = 0
        
        while not done:
            if global_step < args.replay_size:
                a = train_env.action_space.sample()
            else:
                a = agent.act(cur_o, goal_o, args.device).detach().cpu().numpy()
            
            nxt_o, r, d, _ = train_env.step(a)
            done = train_env.goal_space.contains(cur_o[-OBS_DIM:]) or in_episode_step >= args.max_steps
            total_r += r
            
            agent.memory.push(cur_o, a, nxt_o)
            cur_o = nxt_o
            global_step += 1
            in_episode_step += 1
            
            if global_step % args.steps_per_update == 0 and global_step >= args.replay_size:
                critic_loss, actor_loss = agent.update_parameters(args.device)
                writer.add_scalar('loss/critic', critic_loss, update_step)
                writer.add_scalar('loss/actor', critic_loss, update_step)
                update_step += 1
            
            if global_step >= args.replay_size and global_step % args.eval_interval == 0:
                reach_freq = evaluate_policy(eval_env, agent, args.device)
                print(f'-----Global step: {global_step} | reached/total: {reach_freq}-----')

            if global_step >= args.num_steps:
                writer.close()
                agent.to(torch.device('cpu'))
                agent.save_checkpoint(env_name=args.env_name)
                return None
            
        print(f'Episode: {i_episode} | reward: {total_r}')

def evaluate_policy(env, agent, device, num_episodes=10):
    num_reached = 0
    for i_episode in range(num_episodes):
        cur_o = env.reset()
        goal_o = random.choice(agent.goals)
        done = False
        in_episode_step = 0
            
        while not done:
            a = agent.act(cur_o, goal_o, device).detach().cpu().numpy()

            nxt_o, r, d, _ = env.step(a)
            reached = env.goal_space.contains(cur_o[-OBS_DIM:])
            if reached or in_episode_step >= agent.max_steps:
                if reached:
                    num_reached += 1
                break
                
            cur_o = nxt_o
            in_episode_step += 1
                
    return num_reached / num_episodes


def make_env(args):
    ml1 = metaworld.ML1(args.env_name) # Construct the benchmark, sampling tasks
    task = random.choice(ml1.train_tasks)
    env = ml1.train_classes[args.env_name]()
    env.set_task(task)
    return env


if __name__ == '__main__':
    args = parser.parse_args()
    print(args)
    
    train_env = make_env(args)
    eval_env = make_env(args)
    agent = CLearning(train_env, args)
    # print(agent.goals)
    train(train_env, eval_env, agent, args)